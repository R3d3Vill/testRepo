insert into students(student_id,student_name,student_email,batch) values('STD101', 'Om Gupta','ogupta261@gmail.com', 'A');
insert into students(student_id,student_name,student_email,batch) values('STD102', 'Raju Deka','raju95@gmail.com', 'A');
insert into students(student_id,student_name,student_email,batch) values('STD103', 'Amit Yadav','amit067@gmail.com', 'B');
insert into students(student_id,student_name,student_email,batch) values('STD104', 'Abhishek Yadav','abhishek2002@gmail.com', 'B');