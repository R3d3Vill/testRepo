package com.cg.feedback.trainer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
