insert into programs(program_id,program_name)  values('PRG101', 'DevOps');
insert into programs(program_id,program_name)  values('PRG102', 'Oracle');
insert into programs(program_id,program_name)  values('PRG103', 'MVC');
insert into programs(program_id,program_name)  values('PRG104', 'Spring');
