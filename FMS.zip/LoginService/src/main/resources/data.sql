insert into login_credentials(user_id,password,role) values('TRN101','trainer101','Trainer');
insert into login_credentials(user_id,password,role) values('TRN102','trainer102','Trainer');
insert into login_credentials(user_id,password,role) values('TRN103','trainer103','Trainer');
insert into login_credentials(user_id,password,role) values('TRN104','trainer104','Trainer');

insert into login_credentials(user_id,password,role) values('STD101','student101','Student');
insert into login_credentials(user_id,password,role) values('STD102','student102','Student');
insert into login_credentials(user_id,password,role) values('STD103','student103','Student');
insert into login_credentials(user_id,password,role) values('STD104','student104','Student');

insert into login_credentials(user_id,password,role) values('ADM101','admin101','Admin');