

insert into trainers(trainer_id,trainer_name,trainer_skills,trainer_email) values('TRN101', 'Rahul Verma','' ,'rahulverma@gmail.com');
insert into trainers(trainer_id,trainer_name,trainer_skills,trainer_email) values('TRN102', 'Amit Deshpande','' ,'amitdeshpande@gmail.com');
insert into trainers(trainer_id,trainer_name,trainer_skills,trainer_email) values('TRN103', 'Aman Jadhav', '','amanjadhav@gmail.com');
insert into trainers(trainer_id,trainer_name,trainer_skills,trainer_email) values('TRN104', 'Raj Kashyap', '', 'rajkashyap@gmail.com');
