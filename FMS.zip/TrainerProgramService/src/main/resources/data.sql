INSERT INTO program_trainers(trainer_id,program_id,batch) VALUES
    ('TRN101', 'PRG101', 'A'),
    ('TRN102', 'PRG103', 'A'),
    ('TRN103', 'PRG102', 'B'),
    ('TRN104', 'PRG104', 'B'),
    ('TRN101', 'PRG103', 'B'),
    ('TRN102', 'PRG101', 'B');