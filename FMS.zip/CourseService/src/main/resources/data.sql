insert into courses(course_id,course_name) values('CRS101', 'Java Cloud');
insert into courses(course_id,course_name) values('CRS102', 'Java Big Data');
insert into courses(course_id,course_name) values('CRS103', 'Java ');