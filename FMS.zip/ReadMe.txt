Swagger and Actuator Applied in Top 3 services
1.Admin-User
2.Trainer-User
3.Studnet-User

>>Hystrix Applied for Post methods of Admin-User Service 

>>Feedback report is genereated in Admin-User Service

>>Defaulters generated in both admin-user and trainer-user 

>>All rest end points tested on H2 working Fine 


>>Login Response is given by User Service 