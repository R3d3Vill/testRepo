insert into feedbacks(feedback_id,student_id,trainer_id,program_id,q1,q2,q3,q4,q5,comments,suggestions) values(1, 'STD101', 'TRN101', 'PRG101', 3, 4, 3, 4, 4, 'Great.', 'Nothing');
insert into feedbacks(feedback_id,student_id,trainer_id,program_id,q1,q2,q3,q4,q5,comments,suggestions) values(2, 'STD102', 'TRN101', 'PRG101', 5, 4, 3, 3, 4, 'Good.', 'NA');
