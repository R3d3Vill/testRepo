package com.sunhome.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sunhome.dao.CartItemRepository;
import com.sunhome.dto.CartItem;
@Service
public class CartServiceImpl implements CartService {
	
@Autowired
CartItemRepository cartDao;

	@Override
	public String addToCart(CartItem item) {
		double cartValue=0;
		if(item.getQuantity()<new RestTemplate().getForObject("http://localhost:8081/stocks/"+item.getProductId(),Integer.class))
		{	cartDao.save(item);
			for(CartItem temp:cartDao.findAll())
			{
				cartValue+=(temp.getQuantity()*(new RestTemplate().getForObject("http://localhost:8082/products/price/id="+temp.getProductId(), Double.class)));
			}
			return "Total Cart amount is: Rs. "+cartValue;
			
		}
		else
			return "Not sufficient Units";
	}
	

}
