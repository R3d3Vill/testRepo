package com.sunhome.service;

public interface InventoryService {
	
	int getStocks(int productId);

}
